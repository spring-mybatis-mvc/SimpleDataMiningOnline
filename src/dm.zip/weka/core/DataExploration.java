package dm.weka.core;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.HashMap;

import weka.core.Attribute;
import weka.core.Instances;
import weka.core.converters.ConverterUtils.DataSource;
import weka.experiment.Stats;

public class DataExploration {
	
	private Instances instances = null;
	public static final String[] statisKeys = {"name","Missing","Count","Type","Mean","Std","Mix","Min"};
	public static final String[] dataInfo = {"dataSetName","numInstances","numAttributes"};
	public DataExploration(){
		
	}
	
	public DataExploration(String datapath) throws Exception {
		setInstances(datapath);
	}
	
	public void setInstances(String datapath) throws Exception{
		DataSource source = new DataSource(datapath);
		this.instances = source.getDataSet(); //加载数据
		if(this.instances.classIndex() == -1) {			//设置标签
			this.instances.setClassIndex(this.instances.numAttributes() -1);
		}
	}
	
	public void setInstances(Instances instances) {
		this.instances = instances;
	}
	
	public Instances getInstances() {
		return this.instances;
	}
	
	public void setClassIndex(int classIndex) {
		this.instances.setClassIndex(classIndex);
	}
	
	public String[] getAttributeNames() {
		
		int numAttributes = this.instances.numAttributes();		
		String[] attNames = new String[numAttributes];
		for(int i=0;i<numAttributes;i++){
			attNames[i] = this.instances.attribute(i).name();
		}
		return  attNames;
	}
	
	public String[] getValue(int index) {
		String[] instanceValue = null;
		instanceValue = this.instances.instance(index).toString().split(",");
		return instanceValue;
	}
	
	public List<String[]> getValue(){
		List<String[]> instancesValue =  new ArrayList<String[]>();
		int length =  this.instances.size();
		for(int i=0; i<length; i++) {
			String[] value = getValue(i);
			instancesValue.add(value);
		}
		return instancesValue;
	}
	
	public Map<String,String> getDataInfo() {
		Map<String,String> info = new HashMap<String,String>();
		info.put("dataSetName",this.instances.relationName());
		info.put("numAttributes", String.valueOf(this.instances.numAttributes()));
		info.put("numInstances",String.valueOf(this.instances.numInstances()));
		return info;		
	}
	
	public Map<String,String> getAttributeInfo(int index){		
		
		Attribute att = this.instances.attribute(index);
		String type = Attribute.typeToString(att);
		Map<String,String> attMap = new HashMap<String, String>();
		attMap.put("name",att.name());
	    switch (type) {
	    	case "numeric":
	    		DecimalFormat df = new DecimalFormat("0.000"); //保留3位有效小数
	    		attMap.put("Type", type);
	    		attMap.put("Missing", String.valueOf(this.instances.attributeStats(index).missingCount));
	    		Stats stats = this.instances.attributeStats(index).numericStats;
	    		attMap.put("Count",String.valueOf(stats.count));
	    		attMap.put("Mean",df.format(stats.mean));
	    		attMap.put("Std", df.format(stats.stdDev));
	    		attMap.put("Min",String.valueOf(stats.min));
	    		attMap.put("Max",String.valueOf(stats.max));
	    		break;
	    	case "nominal":
	    		attMap.put("Type", type);
	    		attMap.put("Missing", String.valueOf(this.instances.attributeStats(index).missingCount));
	    		Enumeration<Object> eunm = att.enumerateValues();
	    		int[] values = this.instances.attributeStats(index).nominalCounts;
	    		int i = 0;
	    		while(eunm.hasMoreElements()) {
	    			String label = (String)eunm.nextElement();
	    			attMap.put(label,String.valueOf(values[i]));
	    			i++;
	    		}
	    		break;
	    }	
	    return attMap;
	}
	
	public Map<String,Map<String,String>> getDataDescribe(){
		
		int numAtt = this.instances.numAttributes();
		Map<String, Map<String,String>> desc = new HashMap<String, Map<String,String>>();
		for(int i=0; i<numAtt; i++) {
			String attName = this.instances.attribute(i).name();
			Map<String, String> attMap = getAttributeInfo(i);
			desc.put(attName, attMap);			 
		}
		return desc;
	}
	
	public void shuffling(long seed) {
		this.instances.randomize(new Random(seed));
		
	}
}
