package dm.dao;

public class Factory {
	
	public Factory() {
		
	}
	
	public static DataSetDAO getDataSetDao() throws Exception {
		DataSetDAO dao = new DataSetDAO();
		return dao;
	}
}
